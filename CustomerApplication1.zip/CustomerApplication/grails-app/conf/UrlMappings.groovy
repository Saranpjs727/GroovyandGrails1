class UrlMappings {

	static mappings = {
        "/$controller/$action?/$id?(.${format})?"{
            constraints {
                // apply constraints here
            }
        }

        "/"(action:"/create",controller:"country")
        "500"(view:'/error')
	}
}
