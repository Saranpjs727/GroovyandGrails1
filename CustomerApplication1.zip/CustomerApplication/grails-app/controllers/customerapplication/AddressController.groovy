package customerapplication

class AddressController {
    def create(){
        def districtList=District.list()
        render(view:"create",model:[districtList:districtList])
    }
    def operation()
    {
    }
    def save() { 
        def districtId=params.districtList
        def id=Integer.parseInt(districtId)
        def districtIns=District.get(id)
        def addressIns=new Address()
        addressIns.doorNo=params.doorNo
        addressIns.street=params.street
        addressIns.area=params.area
        addressIns.district=districtIns
        addressIns.pincode=params.pincode
        if(addressIns.validate()){
            addressIns.save(flush:true,failOnError:true)
            render view:"operation"
        }
        else{
            flash.message="Please check all the fields"
            def districtList=District.list()
            render(view:"create",model:[districtList:districtList])
        }
    }
    def display()
    {
        def addressList=Address.list()
        [temp:addressList]
    }
    def delete()
    {
        def addressList=Address.list()
        render(view:"delete",model:[addressList:addressList])
    }
    def deleteAction()
    {
        def doorNo=params.doorNo
        def addressInst=Address.get(doorNo)
        addressInst.delete(flush:true)
        render view:"operation"
    }
    //    def update()
    //    {
    //         def stateList=State.list()
    //         render(view:"update",model:[stateList:stateList])
    //    }
    //    def updateAction()
    //    {
    //        def id1=params.oldState
    //        def id=Integer.parseInt(id1)
    //        def stateOld=State.get(id)
    //        def stateNew=params.newState
    //        State.executeUpdate("update State s set s.state='"+stateNew+"' where s.id='"+id+"'")
    //        render view:"operation"
    //     }
}

