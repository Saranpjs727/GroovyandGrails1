package customerapplication
//import java.lang.*;
class CountryController {

    def create() { 
        //  def country=new Country()
    }
    def operation()
    {
    }
    def save()
    {
        def countryInst=new Country(params)
        if(countryInst.validate()){
            countryInst.save(flush:true,failOnError:true)
            render view:"operation"
        }
        else{
            flash.message="Please check all the fields"
            render view:"create"
        }
       
    }
    def display()
    {
        def countryList=Country.list()
        [temp:countryList]
    }
    def delete()
    {
        def countryList=Country.list()
        render(view:"delete",model:[countryList:countryList])
    }
    def deleteAction()
    {
        def country=params.country
        def countryInst=Country.get(country)
        countryInst.delete(flush:true)
        render view:"operation"
    }
    def update()
    {
        def countryList=Country.list()
        render(view:"update",model:[countryList:countryList])
    }
    def updateAction()
    {
        def id1=params.oldCountry
        def id=Integer.parseInt(id1)
        // int id= country as Integer
        def countryOld=Country.get(id)
        def countryNew=params.newCountry
        Country.executeUpdate("update Country c set c.country='"+countryNew+"' where c.id='"+id+"'")
        render view:"operation"
    }
}

